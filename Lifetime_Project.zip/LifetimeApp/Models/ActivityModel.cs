﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace LifetimeApp.Models
{
    public class ActivityModel
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public int UserId { get; set; }

        public string Title { get; set; } = string.Empty;

        public string DayOfWeek { get; set; } = string.Empty;

        public DateTime Date { get; set; } = DateTime.Today;

        public string StartTime { get; set; } = string.Empty;

        public string EndTime { get; set; } = string.Empty;

        public bool CrossesMidnight { get; set; }

        public bool IsAllDay { get; set; }

        public bool IsEveryWeek { get; set; } = false;

        public string FriendNames { get; set; } = string.Empty;

    }
}
