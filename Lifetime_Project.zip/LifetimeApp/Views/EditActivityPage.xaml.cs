﻿using LifetimeApp.Database;
using LifetimeApp.Models;

namespace LifetimeApp.Views;

public partial class EditActivityPage : ContentPage
{
    public ActivityModel activities { get; set; }

    public DatabaseService DatabaseService { get; set; }

    public EditActivityPage(ActivityModel activity)
    {
        InitializeComponent();
        activities = activity;
        BindingContext = activities;
    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void OnSaveClicked(object sender, EventArgs e)
    {
        if (startDateButton.Text == endDateButton.Text) {
            // ตรวจสอบข้อมูลที่จำเป็น
            if (string.IsNullOrWhiteSpace(activityTitleEntry.Text))
            {
                await DisplayAlert("Error", "Please enter activity title", "OK");
                return;
            }

            // ดึงข้อมูลผู้ใช้
            int userId = Preferences.Get("LoggedInUserId", -1);
            if (userId == -1)
            {
                await DisplayAlert("Error", "User not found", "OK");
                return;
            }

            // ตรวจสอบว่าเป็น All Day หรือไม่
            bool isAllDay = !startTimeButton.IsVisible;

            if (isAllDay)
            {
                // สร้างกิจกรรมทั้งวัน
                await App.Database.UpdateActivityAsync(activities);
            }
            else
            {
                // ตรวจสอบเวลาทับซ้อนสำหรับแต่ละวันในช่วงวันที่เลือก
                bool hasOverlap = true;
                var startDate = hiddenStartDatePicker.Date;
                var endDate = hiddenEndDatePicker.Date;
                var startTime = TimeSpan.Parse(startTimeButton.Text);
                var endTime = TimeSpan.Parse(endTimeButton.Text);

                // ตรวจสอบแต่ละวันในช่วงที่เลือก
                for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
                {
                    hasOverlap = await HasTimeOverlap(userId, date, startTime, endTime);
                    break;
                }

                if (hasOverlap)
                {
                    await DisplayAlert("Warning", "This activity overlaps with existing activities", "OK");
                    return;
                }

                // สร้างกิจกรรมปกติ
                await App.Database.UpdateActivityAsync(activities);
            }

            // ปิดหน้าและกลับไปยังปฏิทิน
            await Navigation.PopAsync();
        }
        else
        {
            if (string.IsNullOrWhiteSpace(activityTitleEntry.Text))
            {
                await DisplayAlert("Error", "Please enter activity title", "OK");
                return;
            }

            int userId = Preferences.Get("LoggedInUserId", -1);
            if (userId == -1)
            {
                await DisplayAlert("Error", "User not found", "OK");
                return;
            }

            if (!int.TryParse(hoursEntry.Text, out int requiredHours) || requiredHours <= 0)
            {
                await DisplayAlert("Error", "Please enter valid hours", "OK");
                return;
            }

            DateTime startDate = hiddenStartDatePicker.Date;
            DateTime endDate = hiddenEndDatePicker.Date;

            var availableSlots = await GetAvailableHoursInRangeAsync(userId, startDate, endDate);
            int totalAvailable = availableSlots.Sum(slot => slot.availableHours.Count);

            if (totalAvailable < requiredHours)
            {
                await DisplayAlert("Warning",
                    $"Not enough available time. You need {requiredHours} hours but only {totalAvailable} hours available",
                    "OK");
                return;
            }

            await DistributeActivity(userId, activityTitleEntry.Text, requiredHours, availableSlots);

            await DisplayAlert("Success", "Activity added successfully", "OK");
            await Navigation.PopAsync();
        }
    }

    private async Task<bool> HasTimeOverlap(int userId, DateTime date, TimeSpan newStart, TimeSpan newEnd)
    {
        // ดึงกิจกรรมที่มีอยู่สำหรับวันนั้น
        var existingActivities = await App.Database.GetActivitiesByDateAsync(userId, date);

        foreach (var activity in existingActivities)
            if (activity.Id != activities.Id)
            {
                {
                    // ข้ามกิจกรรม All Day
                    if (activity.IsAllDay) continue;

                    var existingStart = TimeSpan.Parse(activity.StartTime);
                    var existingEnd = TimeSpan.Parse(activity.EndTime);

                    // ตรวจสอบการทับซ้อน
                    if (activity.CrossesMidnight == true)
                    {
                        if (newStart < existingEnd)
                        {
                            return true;
                        }
                        else if (newStart > existingStart)
                        {
                            return true;
                        }
                        else if (newEnd < existingEnd)
                        {
                            return true;
                        }
                        else if (newEnd > existingStart)
                        {
                            return true;
                        }

                    }
                    else if (newStart >= existingStart && newStart < existingEnd)
                    {
                        return true;
                    }
                    else if (newEnd > existingStart && newEnd <= existingEnd)
                    {
                        return true;
                    }
                    else if (newStart <= existingStart && newEnd >= existingEnd)
                    {
                        return true;
                    }

                }
            }

        return false;
    }

    private void OnStartDateButtonClicked(object sender, EventArgs e)
    {
        hiddenStartDatePicker.Focus();
    }

    private void OnEndDateButtonClicked(object sender, EventArgs e)
    {
        hiddenEndDatePicker.Focus();
    }

    private void OnStartDateSelected(object sender, DateChangedEventArgs e)
    {
        startDateButton.Text = e.NewDate.ToString("dd MMM yyyy");

        if (hiddenEndDatePicker.Date < e.NewDate)
        {
            hiddenEndDatePicker.Date = e.NewDate;
            endDateButton.Text = e.NewDate.ToString("dd MMM yyyy");
        }

        hiddenEndDatePicker.MinimumDate = e.NewDate;
    }

    private void OnEndDateSelected(object sender, DateChangedEventArgs e)
    {
        var startDate = hiddenStartDatePicker.Date;
        var endDate = hiddenEndDatePicker.Date;

        if (endDate > startDate)
        {
            // แสดงช่องกรอก workHour
            workHour.IsVisible = true;

            // ซ่อนปุ่มเวลา
            startTimeButton.IsVisible = false;
            endTimeButton.IsVisible = false;
            startDateButton.SetValue(Grid.ColumnProperty, 2);
            endDateButton.SetValue(Grid.ColumnProperty, 2);
            hiddenStartDatePicker.SetValue(Grid.ColumnProperty, 2);
            hiddenEndDatePicker.SetValue(Grid.ColumnProperty, 2);
        }
        else
        {
            // ซ่อนช่องกรอก workHour
            workHour.IsVisible = false;

            // แสดงปุ่มเวลา
            startTimeButton.IsVisible = true;
            endTimeButton.IsVisible = true;
            startDateButton.SetValue(Grid.ColumnProperty, 1);
            endDateButton.SetValue(Grid.ColumnProperty, 1);
            hiddenStartDatePicker.SetValue(Grid.ColumnProperty, 1);
            hiddenEndDatePicker.SetValue(Grid.ColumnProperty, 1);
        }
        endDateButton.Text = e.NewDate.ToString("dd MMM yyyy");
    }

    private void OnTapOutside(object sender, EventArgs e)
    {
        timeOptionsLayoutStart.IsVisible = false;
        timeOptionsLayoutEnd.IsVisible = false;
    }

    private void OnScrollChanged(object sender, EventArgs e)
    {
        timeOptionsLayoutStart.IsVisible = false;
        timeOptionsLayoutEnd.IsVisible = false;
    }

    private void AllDayCkeck(object sender, EventArgs e)
    {
        if (startTimeButton.IsVisible == true && endTimeButton.IsVisible == true)
        {
            startTimeButton.IsVisible = false;
            endTimeButton.IsVisible = false;
            startDateButton.SetValue(Grid.ColumnProperty, 2);
            endDateButton.SetValue(Grid.ColumnProperty, 2);
            hiddenStartDatePicker.SetValue(Grid.ColumnProperty, 2);
            hiddenEndDatePicker.SetValue(Grid.ColumnProperty, 2);
        }
        else
        {
            startTimeButton.IsVisible = true;
            endTimeButton.IsVisible = true;
            startDateButton.SetValue(Grid.ColumnProperty, 1);
            endDateButton.SetValue(Grid.ColumnProperty, 1);
            hiddenStartDatePicker.SetValue(Grid.ColumnProperty, 1);
            hiddenEndDatePicker.SetValue(Grid.ColumnProperty, 1);
        }
    }

    private void OnStartTimeButtonClicked(object sender, EventArgs e)
    {
        // ตรวจสอบว่ามีเมธอด DisplayHourOptions หรือไม่
        DisplayHourOptions(true);
    }

    private void OnEndTimeButtonClicked(object sender, EventArgs e)
    {
        DisplayHourOptions(false);
    }

    private void DisplayHourOptions(bool isStartTime)
    {
        timeOptionsLayoutStartScroll.IsVisible = false;
        timeOptionsLayoutEndScroll.IsVisible = false;

        var targetLayout = isStartTime ? timeOptionsLayoutStart : timeOptionsLayoutEnd;
        var scrollContainer = isStartTime ? timeOptionsLayoutStartScroll : timeOptionsLayoutEndScroll;
        var targetButton = isStartTime ? startTimeButton : endTimeButton;

        targetLayout.Children.Clear();

        int hourStart = 0;
        int hourEnd = 23;

        if (hiddenStartDatePicker.Date == DateTime.Today)
            hourStart = DateTime.Now.Hour + 1;

        // ถ้าเลือก EndTime → ต้องเริ่มหลัง StartTime
        if (!isStartTime)
        {
            if (TimeSpan.TryParse(startTimeButton.Text, out var startTime))
            {
                hourStart = startTime.Hours + 1;
            }
        }

        for (int hour = hourStart; hour <= hourEnd; hour++)
        {
            string timeText = $"{hour:00}:00";
            var button = new Button
            {
                Text = timeText,
                Margin = new Thickness(5, 2),
                BackgroundColor = Colors.LightGray
            };

            button.Clicked += (s, e) =>
            {
                if (isStartTime)
                {
                    startTimeButton.Text = timeText;

                    if (TimeSpan.TryParse(timeText, out var selectedStartTime)
                        && TimeSpan.TryParse(endTimeButton.Text, out var currentEndTime))
                    {
                        if (currentEndTime <= selectedStartTime)
                        {
                            // ถ้า EndTime เดิมน้อยกว่าหรือเท่ากับ StartTime ให้ปรับใหม่
                            int newEndHour = selectedStartTime.Hours + 1;
                            if (newEndHour <= 23)
                            {
                                endTimeButton.Text = $"{newEndHour:00}:00";
                            }
                            else
                            {
                                endTimeButton.Text = "23:59";
                            }
                        }
                        // ถ้า EndTime เดิมยังอยู่หลัง StartTime → ไม่ต้องทำอะไร
                    }
                }
                else
                {
                    endTimeButton.Text = timeText;
                }

                scrollContainer.IsVisible = false;
            };


            targetLayout.Children.Add(button);
        }

        scrollContainer.IsVisible = true;
    }

    private async void deleteClicked(object sender, EventArgs e)
    {
        bool confirm = await DisplayAlert("Confirm", "Do you want to delete this Activity?", "Yes", "No");

        if (confirm)
        {
            await DisplayAlert("Deleted", "Activity has been deleted", "Confirm");
            await App.Database.DeleteActivityAsync(activities);
            await Navigation.PopAsync();
        }
        else
        {

        }
    }

    private async Task<List<(DateTime date, List<int> availableHours)>> GetAvailableHoursInRangeAsync(int userId, DateTime startDate, DateTime endDate)
    {
        var allActivities = await App.Database.GetActivitiesByUserIdAsync(userId);

        var result = new List<(DateTime, List<int>)>();

        for (DateTime date = startDate.Date; date <= endDate.Date; date = date.AddDays(1))
        {
            string dayName = date.DayOfWeek.ToString();
            HashSet<int> occupied = new();

            var relevantActivities = allActivities
                .Where(a =>
                    (a.Date == date.Date) ||  // กิจกรรมแบบระบุวันที่
                    (a.DayOfWeek == "EveryDay") || // ทำทุกวัน
                    (a.DayOfWeek == dayName)       // ตรงกับชื่อวัน
                ).ToList();

            foreach (var act in relevantActivities)
            {
                if (TimeSpan.TryParse(act.StartTime, out var start) && TimeSpan.TryParse(act.EndTime, out var end))
                {
                    if (end <= start)
                    {
                        // ข้ามคืน เช่น 22:00 - 06:00
                        for (int h = start.Hours; h < 24; h++)
                            occupied.Add(h);
                        for (int h = 0; h < end.Hours; h++)
                            occupied.Add(h);
                    }
                    else
                    {
                        for (int h = start.Hours; h < end.Hours; h++)
                            occupied.Add(h);
                    }
                }
            }

            // หาชั่วโมงว่างทั้งหมด (0-23)
            var available = Enumerable.Range(0, 24).Where(h => !occupied.Contains(h)).ToList();
            result.Add((date, available));
        }

        return result;
    }


    private async Task DistributeActivity(int userId, string title, int hoursNeeded, List<(DateTime date, List<int> availableHours)> slots)
    {
        int remaining = hoursNeeded;

        foreach (var slot in slots)
        {
            if (remaining <= 0)
                break;

            var sorted = slot.availableHours.OrderBy(h => h).ToList();
            if (!sorted.Any()) continue;

            var grouped = new List<List<int>>();
            var currentGroup = new List<int> { sorted[0] };

            for (int i = 1; i < sorted.Count; i++)
            {
                if (sorted[i] == sorted[i - 1] + 1)
                    currentGroup.Add(sorted[i]);
                else
                {
                    grouped.Add(currentGroup);
                    currentGroup = new List<int> { sorted[i] };
                }
            }
            grouped.Add(currentGroup);

            foreach (var group in grouped)
            {
                if (remaining <= 0)
                    break;

                int useCount = Math.Min(group.Count, remaining);
                int startHour = group.First();
                int endHour = startHour + useCount;

                var activity = new ActivityModel
                {
                    UserId = userId,
                    Title = title,
                    Date = slot.date,
                    DayOfWeek = slot.date.DayOfWeek.ToString(),
                    StartTime = $"{startHour:00}:00",
                    EndTime = $"{endHour % 24:00}:00",
                    IsAllDay = false
                };

                await App.Database.SaveActivityAsync(activity);
                remaining -= useCount;
            }
        }
        await App.Database.DeleteActivityAsync(activities);
    }
}