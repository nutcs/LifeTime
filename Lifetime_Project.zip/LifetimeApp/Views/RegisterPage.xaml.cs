﻿using LifetimeApp.Database; // ใช้ UserDatabase
using LifetimeApp.Models;

namespace LifetimeApp.Views;

public partial class RegisterPage : ContentPage
{
    private UserDatabase _userDatabase;

    public RegisterPage()
    {
        InitializeComponent();
        // กำหนดเส้นทางฐานข้อมูล (dbPath) ในตัวอย่างนี้ใช้ LocalDatabasePath ที่กำหนดไว้ใน App
        _userDatabase = App.Database.UserDb;
    }

    private async void navigate_LoginPage(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private void showPassword_CheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        password.IsPassword = !e.Value;
    }

    private void showConfirmPassword_CheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        confirmPassword.IsPassword = !e.Value;
    }

    // save database
    private async void register(object sender, EventArgs e)
    {
        string fname = firstName.Text;
        string lname = lastName.Text;
        string user = userName.Text;
        string pass = password.Text;
        string confirm = confirmPassword.Text;
        bool ageValid = int.TryParse(age.Text, out int ageInt);

        if (string.IsNullOrWhiteSpace(fname) || string.IsNullOrWhiteSpace(lname) ||
            string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass) ||
            string.IsNullOrWhiteSpace(confirm) || !ageValid)
        {
            await DisplayAlert("Error", "Please fill in all fields correctly.", "OK");
            return;
        }
        else if (pass != confirm)
        {
            await DisplayAlert("Error", "Passwords do not match.", "OK");
            return;
        }

        // ใช้ UserDatabase แทน App.Database
        var existingUser = await _userDatabase.GetUserByUsernameAsync(user);
        if (existingUser != null)
        {
            await DisplayAlert("Error", "Username already exists.", "OK");
            return;
        }



        var newUser = new User
        {
            FirstName = fname,
            LastName = lname,
            Age = ageInt,
            UserName = user,
            Password = pass // คุณสามารถใช้ hashing ได้ใน production
        };


        await _userDatabase.SaveUserAsync(newUser); // ใช้ SaveUserAsync จาก UserDatabase
        //showUserAll(); //******************** Test
        await DisplayAlert("Success", "Registration complete!", "OK");
        await Navigation.PopAsync(); // กลับไปหน้า login หรือหน้าแรก
    }

    private async void showUserAll()
    {
        var allUsers = await _userDatabase.GetUserAllAsync();

        string userList = "";
        foreach (var user in allUsers)
        {
            userList += $"Name: {user.FirstName} {user.LastName}, " +
                        $"Username: {user.UserName}, Age: {user.Age}, " +
                        $"Configured: {user.IsConfigured}\n" +
                        $"Password: {user.Password}";
        }

        await DisplayAlert("All Users", userList, "OK");

    }
}