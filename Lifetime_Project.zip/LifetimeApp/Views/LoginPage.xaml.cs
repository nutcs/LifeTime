﻿using System;
using Microsoft.Maui.Controls;
using System.Threading.Tasks;
using LifetimeApp.Database;
using LifetimeApp.Models;

namespace LifetimeApp.Views
{
    public partial class LoginPage : ContentPage
    {
        private UserDatabase _userDatabase;

        public LoginPage()
        {
            InitializeComponent();
            _userDatabase = App.Database.UserDb; // ใช้ UserDatabase ที่ประกาศไว้
            //showUserAll();

        }
        private async void showUserAll() 
        {
            var allUsers = await _userDatabase.GetUserAllAsync();

            string userList = "";
            foreach (var user in allUsers)
            {
                userList += $"Name: {user.FirstName} {user.LastName}, " +
                            $"Username: {user.UserName}, Age: {user.Age}, " +
                            $"Configured: {user.IsConfigured}, " +
                            $"Password: {user.Password}\n";
            } 

            await DisplayAlert("All Users", userList, "OK");

        }

        private async void Login_Clicked(object sender, EventArgs e)
        {
            string username = Username.Text?.Trim();
            string password = Password.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                await DisplayAlert("Error", "Please enter both username and password.", "OK");
                return;
            }

            var user = await _userDatabase.GetUserByUsernameAsync(username);  // ใช้ _userDatabase แทน
            if (user == null || user.Password != password)
            {
                await DisplayAlert("Login Failed", "Incorrect username or password.", "OK");
                return;
            }

            // เซฟผู้ใช้ลง Preferences เผื่อใช้ต่อ
            Preferences.Set("LoggedInUserId", user.Id);
            if (user != null && user.IsConfigured)
            {
                //*************************
                //await DisplayAlert("Debug", $"user != null : {user != null}\n user.IsConfigured : {user.IsConfigured}", "OK");
                await Navigation.PushAsync(new Views.CalendarPage());
                //await Navigation.PushAsync(new Views.CalendarPage2());
            }
            else
            {
                await Navigation.PushAsync(new Views.SettingPage());
            }
        }


        private void showPassword_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            Password.IsPassword = !e.Value;
        }

        private async void Forget_Password(object sender, EventArgs e)
        {
            await DisplayAlert("Forget Password", "Feature not implemented yet.", "OK");
        }

        private async void navigate_Register(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Views.RegisterPage());
        }
    }
}