﻿
using LifetimeApp.Models;
using Microsoft.Maui.Controls.Shapes;
using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace LifetimeApp.Views;

public partial class CalendarPage : ContentPage
{
    private List<Button> dateButtons = new List<Button>();
    private DateTime selectedDate;
    private DateTime weekStartDate;
    private bool workdayEnabled = true;
    //private List<Button> dateLabels = new(); // เพิ่มส่วนนี้ไว้ด้านบนในคลาส


    public class TimeBlock
    {
        public string Text { get; set; }           
        public string BackgroundColorHex { get; set; }  
        public double Opacity { get; set; }          
        public int Row { get; set; }                  
        public int RowSpan { get; set; }              
    }

    public CalendarPage()
    {
        InitializeComponent();

        GenerateWeekDates();
        selectedDate = DateTime.Today;
        LoadActivities();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        // เคลียร์กิจกรรมที่แสดงอยู่ทั้งหมด
        ClearExistingActivities();

        // โหลดกิจกรรมใหม่สำหรับวันที่เลือก
        LoadActivities();
    }


    private void GenerateWeekDates()
    {
        dateButtons.Clear();
        DateButtonsContainer.Children.Clear();

        DateTime today = DateTime.Today;

        // หา "วันจันทร์" ที่ใกล้ที่สุดก่อนหรือเท่ากับวันนี้
        int daysFromMonday = ((int)today.DayOfWeek + 6) % 7; // เปลี่ยน Sunday=0 เป็น 6
        weekStartDate = today.AddDays(-daysFromMonday);

        for (int i = 0; i < 7; i++)
        {
            DateTime date = weekStartDate.AddDays(i);
            var lab = new Label
            {
                Text = date.ToString("dd"),
                BackgroundColor = Color.FromArgb("#F2F2F7"),
                TextColor = Colors.Black,
                WidthRequest = 45,
                HeightRequest = 25,
                FontAttributes = FontAttributes.Bold,
                FontSize = 12,
            };

            var btn = new Button
            {
                Text = date.ToString("ddd dd"),
                BackgroundColor = Color.FromArgb("#D9D9D9"),
                TextColor = Colors.Black,
                WidthRequest = 45,
                HeightRequest = 45,
                CornerRadius = 20,
                FontAttributes = FontAttributes.Bold,
                FontSize = 12,
                CommandParameter = date
            };

            btn.Clicked += OnDateButtonClicked;

            DateButtonsContainer.Children.Add(btn);
            Date.Children.Add(lab);
            dateButtons.Add(btn);


        }

        SelectDate(today); // เริ่มต้นเลือกวันนี้
    }

    private void OnDateButtonClicked(object sender, EventArgs e)
    {
        if (sender is Button button && button.CommandParameter is DateTime date)
        {
            SelectDate(date);
        }
    }

    private void SelectDate(DateTime date)
    {
        selectedDate = date;

        foreach (var btn in dateButtons)
        {
            btn.BackgroundColor = (DateTime)btn.CommandParameter == selectedDate
                ? Color.FromArgb("#D9D9D9")
                : Color.FromArgb("#F2F2F7");
        }

        DateLabel.Text = selectedDate.ToString("dddd - dd MMM yyyy", new CultureInfo("en-US"));
        Month.Text = date.ToString("MMM");

        // โหลดกิจกรรมใหม่เมื่อเปลี่ยนวันที่
        LoadActivities();
    }

    private void OnSwipedLeft(object sender, SwipedEventArgs e)
    {
        weekStartDate = weekStartDate.AddDays(7);
        UpdateWeekDisplay();
    }

    private void OnSwipedRight(object sender, SwipedEventArgs e)
    {
        weekStartDate = weekStartDate.AddDays(-7);
        UpdateWeekDisplay();
    }

    private void UpdateWeekDisplay()
    {
        dateButtons.Clear();
        DateButtonsContainer.Children.Clear();
        Date.Children.Clear();

        for (int i = 0; i < 7; i++)
        {
            DateTime date = weekStartDate.AddDays(i);

            var lab = new Label
            {
                Text = date.ToString("dd"),
                BackgroundColor = Color.FromArgb("#F2F2F7"),
                TextColor = Colors.Black,
                WidthRequest = 45,
                HeightRequest = 25,
                FontAttributes = FontAttributes.Bold,
                FontSize = 12,
            };

            var btn = new Button
            {
                Text = date.ToString("ddd dd"),
                BackgroundColor = Color.FromArgb("#F2F2F7"),
                TextColor = Colors.Black,
                WidthRequest = 45,
                HeightRequest = 45,
                CornerRadius = 20,
                FontAttributes = FontAttributes.Bold,
                FontSize = 12,
                CommandParameter = date
            };

            btn.Clicked += OnDateButtonClicked;

            DateButtonsContainer.Children.Add(btn);
            Date.Children.Add(lab);
            dateButtons.Add(btn);
        }

        // อัปเดตวันที่ที่เลือกให้เป็นตัวแรกของสัปดาห์ใหม่ (หรือจะเก็บค่าไว้แล้วเลือกตัวเดิมก็ได้)
        SelectDate(weekStartDate);
    }
    private async void LogoutClicked(object sender, EventArgs e)
    {   
        bool Logout = false;
        Logout = await DisplayAlert("Logout", "Are you sure you want to logout?", "Yes", "No");
        if (Logout)
        {
            Preferences.Set("LoggedInUserId", -1);
            await Navigation.PushAsync(new LoginPage());
        }
        else
        {

        }
    }

    private void OnAddButtonClicked(object sender, EventArgs e)
    {
        DropdownMenu.IsVisible = !DropdownMenu.IsVisible;
    }

    private async void GoToSingle(object sender, EventArgs e)
    {
        DropdownMenu.IsVisible = false;
        await Navigation.PushAsync(new Views.SingleDayPage()); // หรือ Navigation.PushModalAsync
    }

    private async void GoToMulti(object sender, EventArgs e)
    {
        DropdownMenu.IsVisible = false;
        await Navigation.PushAsync(new Views.MultiDayPage());
    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    // ใน Database หรือก่อนแสดงผล ให้แยกกิจกรรมข้ามวันเป็น 2 กิจกรรม



    //***************************************************************************************************************************************************
    private async void LoadActivities()
    {
        int userId = Preferences.Get("LoggedInUserId", -1);
        if (userId == -1) return;

        // ดึงข้อมูลกิจกรรมจากฐานข้อมูล
        var activities = await App.Database.GetActivitiesByUserIdAsync(userId);

        // ล้างกิจกรรมเก่าที่แสดงอยู่
        ClearExistingActivities();
        AddContents();

        var dayOfWeek = selectedDate.ToString("dddd");
        var todayActivities = activities.Where(a =>
            a.DayOfWeek == "EveryDay" ||
            (a.DayOfWeek == dayOfWeek && a.IsEveryWeek == true) ||
            a.Date == selectedDate
        ).ToList();

        var prevDay = selectedDate.AddDays(-1);
        var prevDayOfWeek = prevDay.ToString("dddd");
        var prevDayActivities = activities.Where(a =>
            (
                a.DayOfWeek == "EveryDay" ||
                (a.DayOfWeek == prevDayOfWeek && a.IsEveryWeek == true) ||
                a.Date == prevDay
            ) &&
            TimeSpan.TryParse(a.StartTime, out var start) &&
            TimeSpan.TryParse(a.EndTime, out var end) &&
            start > end
        ).ToList();


        // แยกกิจกรรม All Day และปกติ
        var allDayActivities = todayActivities.Where(a => a.IsAllDay).ToList();
        var regularActivities = todayActivities.Where(a => !a.IsAllDay).ToList();

        // แสดงกิจกรรมปกติก่อน
        foreach (var activity in regularActivities.Concat(prevDayActivities))
        {
            AddActivityToCalendar(activity, todayActivities);
        }

        // แสดงกิจกรรม All Day ทีหลัง (จะแสดงเฉพาะส่วนที่ว่าง)
        foreach (var activity in allDayActivities)
        {
            AddActivityToCalendar(activity, todayActivities);
        }
    }

    private void ClearExistingActivities()
    {
        var grid = this.FindByName<Grid>("CalendarGrid");
        var elementsToRemove = grid.Children
            .Where(c => c is Border || (c is Label && c != DateLabel))
            .ToList();

        foreach (var element in elementsToRemove)
        {
            grid.Children.Remove(element);
        }
    }


    // ********************************************************************************************
    private async Task AddActivityToCalendar(ActivityModel activity, List<ActivityModel> existingActivities)
    {
        AddContents();

        var tapGesture = new TapGestureRecognizer();
        tapGesture.Tapped += async (s, e) =>
        {
            // ไปยังหน้าแก้ไขและส่ง activity ไป
            await Navigation.PushAsync(new Views.EditActivityPage(activity));
        };


        var grid = this.FindByName<Grid>("CalendarGrid");
        //await DisplayAlert("All Users", $"{activity.Title}", "OK");
        if (activity.CrossesMidnight)
        {
            AddCrossDayActivity(activity);
            var startTime = TimeSpan.Parse(activity.StartTime);
            var endTime = TimeSpan.Parse(activity.EndTime);

            int startRow = startTime.Hours;
            int endRow = 24;
            int rowSpan = endRow - startRow;

            var border = new Border
            {
                Background = GetActivityColor(activity.Title),
                //Background = Color.FromArgb("#EB4E3D"),
                StrokeShape = new RoundRectangle { CornerRadius = 10 },
                Stroke = Colors.White,
                Padding = new Thickness(10, 5, 10, 5), // ปรับ padding ด้านบนให้น้อยลง
                Content = new Label
                {
                    Text = activity.Title,
                    FontAttributes = FontAttributes.Bold,
                    HorizontalOptions = LayoutOptions.Center,
                    VerticalOptions = LayoutOptions.Start, // ✅ ชิดบน
                    TextColor = Colors.White,
                    Padding = new Thickness(0) // ไม่ต้องมี padding เพิ่ม
                }
            };

            border.GestureRecognizers.Add(tapGesture);
            //Grid.SetRow(border, startRow);
            //Grid.SetRowSpan(border, rowSpan);
            Grid.SetRow(border, startRow);
            Grid.SetRowSpan(border, rowSpan);
            Grid.SetColumn(border, 1);
            grid.Children.Add(border);
            AddLines();
        }
        else if (activity.IsAllDay && activity.Date == selectedDate)
        {
            // หาช่วงเวลาว่าง
            var availableSlots = FindAvailableSlots(activity, existingActivities);


            // สร้าง Border สำหรับแต่ละช่วงเวลาว่าง
            Color background = GetActivityColor(activity.Title);
            foreach (var slot in availableSlots)
            {
                int startRow = slot.start;
                int rowSpan = slot.end - slot.start + 1;

                if (startRow == availableSlots[0].start)
                {
                    var label = new Label
                    {
                        Text = activity.Title,
                        FontAttributes = FontAttributes.Bold,
                        Padding = new Thickness(0),  // ปรับ padding ให้เหมาะสม
                        Margin = new Thickness(0, 5, 0, 0), // ชิดบน
                        HorizontalOptions = LayoutOptions.Center,
                        VerticalOptions = LayoutOptions.Start,
                        TextColor = Colors.White
                    };


                    var border = new Border
                    {
                        Background = background,
                        StrokeShape = new RoundRectangle { CornerRadius = 10 },
                        Stroke = Colors.White,
                        Padding = new Thickness(15),
                        Content = label  // ใส่ label เข้าไปใน border เลย
                    };

                    border.GestureRecognizers.Add(tapGesture);
                    Grid.SetRow(border, startRow);
                    Grid.SetRowSpan(border, rowSpan);
                    Grid.SetColumn(border, 1);
                    grid.Children.Add(border);
                    AddLines();
                }
                else
                {
                    // กรณีไม่ใช่ช่องแรก ให้แค่เพิ่ม border ไม่มี label
                    var border = new Border
                    {
                        Background = background,
                        //Background = Color.FromArgb("#D9D9D9"),
                        StrokeShape = new RoundRectangle { CornerRadius = 10 },
                        Stroke = Colors.White,
                        Padding = new Thickness(15)
                    };

                    border.GestureRecognizers.Add(tapGesture);
                    Grid.SetRow(border, startRow);
                    Grid.SetRow(border, startRow);
                    Grid.SetRowSpan(border, rowSpan);
                    Grid.SetColumn(border, 1);
                    grid.Children.Add(border);
                    AddLines();
                }
            }
        }

        else
        {
            // แสดงกิจกรรมปกติ (เหมือนเดิม)
            

            var startTime = TimeSpan.Parse(activity.StartTime);
            var endTime = TimeSpan.Parse(activity.EndTime);

            int startRow = startTime.Hours;
            int endRow = endTime.Hours;
            int rowSpan = endRow - startRow;
            var border = new Border
            {
                Background = GetActivityColor(activity.Title),
                //Background = Color.FromArgb("#EB4E3D"),
                StrokeShape = new RoundRectangle { CornerRadius = 10 },
                Stroke = Colors.White,
                Padding = new Thickness(10, 5, 10, 5), // ปรับ padding ด้านบนให้น้อยลง
                Content = new Label
                {
                    Text = activity.Title,
                    FontAttributes = FontAttributes.Bold,
                    HorizontalOptions = LayoutOptions.Center,
                    VerticalOptions = LayoutOptions.Start, // ✅ ชิดบน
                    TextColor = Colors.White,
                    Padding = new Thickness(0) // ไม่ต้องมี padding เพิ่ม
                }
            };

            border.GestureRecognizers.Add(tapGesture);
            //Grid.SetRow(border, startRow);
            //Grid.SetRowSpan(border, rowSpan);
            Grid.SetRow(border, startRow);
            Grid.SetRowSpan(border, rowSpan);
            Grid.SetColumn(border, 1);
            grid.Children.Add(border);
        }

    }




    // ********************************************************************************************

    private void AddCrossDayActivity(ActivityModel activity)
    {
        AddContents();
        var grid = this.FindByName<Grid>("CalendarGrid");
        var endTime = TimeSpan.Parse(activity.EndTime);

        // ส่วนที่สองของกิจกรรม (ตั้งแต่เที่ยงคืนจนถึง endTime)
        AddSingleDayActivity(grid, activity, TimeSpan.FromHours(0), endTime);
    }

    private async void AddSingleDayActivity(Grid grid, ActivityModel activity, TimeSpan start, TimeSpan end)
    {
        var tapGesture = new TapGestureRecognizer();
        tapGesture.Tapped += async (s, e) =>
        {
            // ไปยังหน้าแก้ไขและส่ง activity ไป
            await Navigation.PushAsync(new Views.EditActivityPage(activity));
        };

        int startRow = (int)start.TotalHours;
        int endRow = (int)end.TotalHours;
        int rowSpan = endRow - startRow;

        var label = new Label
        {
            Text = activity.Title,
            FontAttributes = FontAttributes.Bold,
            Padding = new Thickness(0, 0, 0, 0), // ไม่ต้อง padding ซ้อนใน
            Margin = new Thickness(0, 2, 0, 0),  // ชิดบนด้วย margin
            VerticalOptions = LayoutOptions.Start, // ชิดบน
            HorizontalOptions = LayoutOptions.Center,
            TextColor = Colors.White
        };

        var border = new Border
        {
            Background = GetActivityColor(activity.Title),
            StrokeShape = new RoundRectangle { CornerRadius = 10 },
            Stroke = Colors.White,
            Padding = new Thickness(10, 6, 10, 6), // ระยะขอบรอบนอกของ Border
            Content = label // ✅ ใส่ label เข้าไปใน border
        };

        //await DisplayAlert("night+1", $"rowSpan = {rowSpan + 1}\n start {startRow}", "OK");

        border.GestureRecognizers.Add(tapGesture);
        Grid.SetRow(border, startRow);
        Grid.SetRowSpan(border, rowSpan);
        Grid.SetColumn(border, 1);
        grid.Children.Add(border); // แค่ add border ก็พอแล้ว
        AddLines();


    }

    private List<(int start, int end)> FindAvailableSlots(ActivityModel activity, List<ActivityModel> existingActivities)
    {
        var availableSlots = new List<(int start, int end)>();

        if (!activity.IsAllDay) return availableSlots;

        // สร้างรายการช่วงเวลาที่ถูกใช้งานแล้ว
        var busySlots = new List<(int start, int end)>();

        foreach (var a in existingActivities.Where(e => !e.IsAllDay))
        {
            var start = TimeSpan.Parse(a.StartTime).Hours;
            var end = TimeSpan.Parse(a.EndTime).Hours;

            if (end > start)
            {
                busySlots.Add((start, end - 1));
            }
            else if (end < start)
            {
                // ข้ามวัน: แยกเป็น 2 ช่วง
                busySlots.Add((start, 23));  // จาก start ถึงสิ้นวัน
                busySlots.Add((0, end - 1)); // จากต้นวันถึง end
            }
            // ถ้า start == end → ถือว่าไม่มีความยาว (อาจข้ามวันเต็ม 24 ชม.) → ข้ามได้หรือเตือน
        }

        busySlots = busySlots.OrderBy(s => s.start).ToList();

        // ถ้าไม่มีกิจกรรมอื่นเลย → ทั้งวันว่าง
        if (!busySlots.Any())
        {
            availableSlots.Add((0, 23));
            return availableSlots;
        }

        // ตรวจสอบช่องว่างก่อนกิจกรรมแรก
        if (busySlots[0].start > 0)
        {
            availableSlots.Add((0, busySlots[0].start - 1));
        }

        // ตรวจสอบช่องว่างระหว่างกิจกรรม
        for (int i = 1; i < busySlots.Count; i++)
        {
            int gapStart = busySlots[i - 1].end + 1;
            int gapEnd = busySlots[i].start - 1;

            if (gapStart <= gapEnd)
            {
                availableSlots.Add((gapStart, gapEnd));
            }
        }

        // ตรวจสอบช่องว่างหลังกิจกรรมสุดท้าย
        if (busySlots.Last().end < 23)
        {
            availableSlots.Add((busySlots.Last().end + 1, 23));
        }

        return availableSlots;
    }



    //***************************************************************************************************************************************************



    private Color GetActivityColor(string title)
    {
        if (title == "Sleep")
        {
            //return Color.FromArgb("#D9D9D9"); 97866A
            return Color.FromArgb("#97866A");
        }
        else if (title == "Work")
        {
            return Color.FromArgb("#EB4E3D");
        }
        else
        {
            // สุ่มจากสีที่กำหนดไว้
            string[] hexColors = { "#e91e63", "#64E2B7", "#A86523", "#3A59D1" };
            Random random = new Random();
            int index = random.Next(hexColors.Length);
            return Color.FromArgb(hexColors[index]);
        }
    }







    private void AddContents()
    {
        AddLines();
        for (int i = 0; i < 24; i++)
        {
            //text left 00;00 , 01:000
            var labelTime = new Label
            {
                TextColor = Color.FromArgb("#000000"), // ������ Hex ����
                Padding = new Thickness(0, 10, 0, 10),
                HorizontalOptions = LayoutOptions.Center,
                FontAttributes = FontAttributes.Bold,
                VerticalOptions = LayoutOptions.Center
            };

            if (i < 10)
            {
                labelTime.Text = $"0{i}:00";
            }
            else
            {
                labelTime.Text = $"{i}:00";
            }
            Grid.SetRow(labelTime, i);
            Grid.SetColumn(labelTime, 0);
            CalendarGrid.Children.Add(labelTime);
        }

    }
    private void AddLines()
    {
        for (int i = 0; i < 24; i++)
        {
            //Line
            var Line = new BoxView
            {
                HeightRequest = 1,
                BackgroundColor = Color.FromArgb("#F2F2F7"),
                VerticalOptions = LayoutOptions.Start,
                Margin = new Thickness(15, 5, 15, 0)
            };

            Grid.SetRow(Line, i);
            Grid.SetColumn(Line, 1);
            CalendarGrid.Children.Add(Line);
        }
    }

}
