﻿using LifetimeApp.Models;
using System.Globalization;

namespace LifetimeApp.Views;

public partial class MultiDayPage : ContentPage
{
    public MultiDayPage()
    {
        InitializeComponent();

        string todayText = DateTime.Now.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
        string tomorrowText = DateTime.Now.AddDays(1).ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
        startDateButton.Text = todayText;
        endDateButton.Text = tomorrowText;

        hiddenEndDatePicker.MinimumDate = DateTime.Now.AddDays(1);
    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void OnAddClicked(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(activityTitleEntry.Text))
        {
            await DisplayAlert("Error", "Please enter activity title", "OK");
            return;
        }

        int userId = Preferences.Get("LoggedInUserId", -1);
        if (userId == -1)
        {
            await DisplayAlert("Error", "User not found", "OK");
            return;
        }

        if (!int.TryParse(hoursEntry.Text, out int requiredHours) || requiredHours <= 0)
        {
            await DisplayAlert("Error", "Please enter valid hours", "OK");
            return;
        }

        DateTime startDate = hiddenStartDatePicker.Date;
        DateTime endDate = hiddenEndDatePicker.Date;

        var availableSlots = await GetAvailableHoursInRangeAsync(userId, startDate, endDate);
        int totalAvailable = availableSlots.Sum(slot => slot.availableHours.Count);

        if (totalAvailable < requiredHours)
        {
            await DisplayAlert("Warning",
                $"Not enough available time. You need {requiredHours} hours but only {totalAvailable} hours available",
                "OK");
            return;
        }

        await DistributeActivity(userId, activityTitleEntry.Text, requiredHours, availableSlots);

        await DisplayAlert("Success", "Activity added successfully", "OK");
        await Navigation.PopAsync();
    }

    private void OnStartDateButtonClicked(object sender, EventArgs e)
    {
        hiddenStartDatePicker.Focus();
    }

    private void OnEndDateButtonClicked(object sender, EventArgs e)
    {
        hiddenEndDatePicker.Focus();
    }

    private void OnStartDateSelected(object sender, DateChangedEventArgs e)
    {
        startDateButton.Text = e.NewDate.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
        DateTime minEndDate = e.NewDate.AddDays(1);

        if (hiddenEndDatePicker.Date < minEndDate)
        {
            hiddenEndDatePicker.Date = minEndDate;
            endDateButton.Text = minEndDate.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
        }

        hiddenEndDatePicker.MinimumDate = minEndDate;
    }

    private void OnEndDateSelected(object sender, DateChangedEventArgs e)
    {
        DateTime minEndDate = hiddenStartDatePicker.Date.AddDays(1);

        if (e.NewDate < minEndDate)
        {
            hiddenEndDatePicker.Date = minEndDate;
            endDateButton.Text = minEndDate.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
        }
        else
        {
            endDateButton.Text = e.NewDate.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
        }
    }

    private void OnWorkTimeTextChanged(object sender, TextChangedEventArgs e)
    {
        var entry = (Entry)sender;
        string newText = new string(entry.Text.Where(char.IsDigit).ToArray());

        if (newText.StartsWith("0") && newText.Length > 1)
            newText = newText.TrimStart('0');

        entry.Text = newText;
    }

    private async Task<List<(DateTime date, List<int> availableHours)>> GetAvailableHoursInRangeAsync(int userId, DateTime startDate, DateTime endDate)
    {
        var allActivities = await App.Database.GetActivitiesByUserIdAsync(userId);

        var result = new List<(DateTime, List<int>)>();

        for (DateTime date = startDate.Date; date <= endDate.Date; date = date.AddDays(1))
        {
            string dayName = date.DayOfWeek.ToString();
            HashSet<int> occupied = new();

            var relevantActivities = allActivities
                .Where(a =>
                    (a.Date == date.Date) ||  // กิจกรรมแบบระบุวันที่
                    (a.DayOfWeek == "EveryDay") || // ทำทุกวัน
                    (a.DayOfWeek == dayName)       // ตรงกับชื่อวัน
                ).ToList();

            foreach (var act in relevantActivities)
            {
                if (TimeSpan.TryParse(act.StartTime, out var start) && TimeSpan.TryParse(act.EndTime, out var end))
                {
                    if (end <= start)
                    {
                        // ข้ามคืน เช่น 22:00 - 06:00
                        for (int h = start.Hours; h < 24; h++)
                            occupied.Add(h);
                        for (int h = 0; h < end.Hours; h++)
                            occupied.Add(h);
                    }
                    else
                    {
                        for (int h = start.Hours; h < end.Hours; h++)
                            occupied.Add(h);
                    }
                }
            }

            // หาชั่วโมงว่างทั้งหมด (0-23)
            var available = Enumerable.Range(0, 24).Where(h => !occupied.Contains(h)).ToList();
            result.Add((date, available));
        }

        return result;
    }


    private async Task DistributeActivity(int userId, string title, int hoursNeeded, List<(DateTime date, List<int> availableHours)> slots)
    {
        int remaining = hoursNeeded;

        foreach (var slot in slots)
        {
            if (remaining <= 0)
                break;

            var sorted = slot.availableHours.OrderBy(h => h).ToList();
            if (!sorted.Any()) continue;

            var grouped = new List<List<int>>();
            var currentGroup = new List<int> { sorted[0] };

            for (int i = 1; i < sorted.Count; i++)
            {
                if (sorted[i] == sorted[i - 1] + 1)
                    currentGroup.Add(sorted[i]);
                else
                {
                    grouped.Add(currentGroup);
                    currentGroup = new List<int> { sorted[i] };
                }
            }
            grouped.Add(currentGroup);

            foreach (var group in grouped)
            {
                if (remaining <= 0)
                    break;

                int useCount = Math.Min(group.Count, remaining);
                int startHour = group.First();
                int endHour = startHour + useCount;

                var activity = new ActivityModel
                {
                    UserId = userId,
                    Title = title,
                    Date = slot.date,
                    DayOfWeek = slot.date.DayOfWeek.ToString(),
                    StartTime = $"{startHour:00}:00",
                    EndTime = $"{endHour % 24:00}:00",
                    IsAllDay = false,
                    FriendNames = friendGird.Text
                };

                await App.Database.SaveActivityAsync(activity);
                remaining -= useCount;
            }
        }
    }
}
