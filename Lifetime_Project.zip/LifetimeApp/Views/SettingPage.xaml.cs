﻿using System;
using LifetimeApp.Models;
using Microsoft.Maui.Controls.Shapes;

namespace LifetimeApp.Views;

public partial class SettingPage : ContentPage
{
    private Button selectedTimeButton;
    private UserDatabase _userDatabase;

    public SettingPage()
    {
        InitializeComponent();
        _userDatabase = App.Database.UserDb;
    }

    private void selectMonday_CheckedChanged(object sender, CheckedChangedEventArgs e) { }
    private void selectTuesday_CheckedChanged(object sender, CheckedChangedEventArgs e) { }
    private void selectWednesday_CheckedChanged(object sender, CheckedChangedEventArgs e) { }
    private void selectThursday_CheckedChanged(object sender, CheckedChangedEventArgs e) { }
    private void selectFriday_CheckedChanged(object sender, CheckedChangedEventArgs e) { }
    private void selectSaturday_CheckedChanged(object sender, CheckedChangedEventArgs e) { }
    private void selectSunday_CheckedChanged(object sender, CheckedChangedEventArgs e) { }

    private async void SaveSettingsButton_Clicked(object sender, EventArgs e)
    {

        int userId = Preferences.Get("LoggedInUserId", -1);
        if (userId == -1)
        {
            await DisplayAlert("Error", "No user ID found.", "OK");
            return;
        }

        // ✅ อัปเดตสถานะว่าได้ตั้งค่าครั้งแรกแล้ว (ทันที)
        var user = await App.Database.GetUserByIdAsync(userId);
        if (user != null && !user.IsConfigured)
        {
            user.IsConfigured = true;
            await App.Database.UpdateUserAsync(user);  // ต้องบันทึกการอัปเดตนี้ให้สำเร็จ

        }

        // ล้างข้อมูลเก่าของผู้ใช้ก่อน
        await App.Database.DeleteActivitiesByUserIdAsync(userId);

        // 1. บันทึกเวลาทำงาน (Work)
        // True , "Monday"
        var workDays = new[] {
            (selectMonday.IsChecked, "Monday"),
            (selectTuesday.IsChecked, "Tuesday"),
            (selectWednesday.IsChecked, "Wednesday"),
            (selectThursday.IsChecked, "Thursday"),
            (selectFriday.IsChecked, "Friday"),
            (selectSaturday.IsChecked, "Saturday"),
            (selectSunday.IsChecked, "Sunday")
        };

        // loop monday to sunday  for  work
        foreach (var (isChecked, day) in workDays)
        {
            if (isChecked)
            {
                var activity = new ActivityModel
                {
                    UserId = userId,
                    Title = "Work",
                    DayOfWeek = day,
                    StartTime = WorkStartButton.Text,
                    EndTime = WorkEndButton.Text,
                    CrossesMidnight = TimeSpan.Parse(WorkStartButton.Text) > TimeSpan.Parse(WorkEndButton.Text),
                    IsEveryWeek = true
                };
                await App.Database.SaveActivityAsync(activity);
            }
        }

        // 2. บันทึกเวลานอน (Sleep)
        var sleepActivity = new ActivityModel
        {
            UserId = userId,
            Title = "Sleep",
            DayOfWeek = "EveryDay",
            StartTime = SleepStartButton.Text,
            EndTime = WakeUpButton.Text,
            CrossesMidnight = TimeSpan.Parse(SleepStartButton.Text) > TimeSpan.Parse(WakeUpButton.Text),
            IsEveryWeek = true
        };

        await App.Database.SaveActivityAsync(sleepActivity);

        // 3. บันทึกกิจกรรมเพิ่มเติมจาก Border ที่มี StyleId == "CustomActivity"
        foreach (var child in settingStackLayout.Children)
        {
            if (child is Border border && border.StyleId == "CustomActivity")
            {
                if (border.Content is StackLayout wrapper)
                {
                    var grid = wrapper.Children.OfType<Grid>().FirstOrDefault();
                    if (grid == null) continue;

                    var entry = grid.Children.OfType<Entry>().FirstOrDefault();
                    var startBtn = grid.Children.OfType<Button>()
                        .FirstOrDefault(b => Grid.GetRow(b) == 2);
                    var endBtn = grid.Children.OfType<Button>()
                        .FirstOrDefault(b => Grid.GetRow(b) == 4);

                    if (entry == null || startBtn == null || endBtn == null) continue;

                    string title = entry.Text;
                    string startTime = startBtn.Text;
                    string endTime = endBtn.Text;

                    var everyDayCheck = wrapper.GetVisualTreeDescendants()
                        .OfType<CheckBox>()
                        .FirstOrDefault(cb => cb.StyleId == "EveryDayCheck");

                    bool isEveryDay = everyDayCheck?.IsChecked ?? false;

                    if (isEveryDay)
                    {
                        //await DisplayAlert("Save EveryDay", $"Title = {title}", "OK");
                        await App.Database.SaveActivityAsync(new ActivityModel
                        {
                            UserId = userId,
                            Title = title,
                            DayOfWeek = "EveryDay",
                            StartTime = startTime,
                            EndTime = endTime,
                            CrossesMidnight = TimeSpan.Parse(startTime) > TimeSpan.Parse(endTime),
                            IsEveryWeek = true
                        });
                    }
                    // ********************************************************
                    else
                    {
                        //var dayStack = wrapper.Children.OfType<StackLayout>().Skip(2).FirstOrDefault();

                        var dayStack = wrapper.Children
                            .OfType<StackLayout>()
                            .FirstOrDefault(sl => sl.Children.OfType<StackLayout>().Any(dl => dl.Children.OfType<CheckBox>().Any()));


                        if (dayStack != null)
                        {
                            foreach (var dayLayout in dayStack.Children.OfType<StackLayout>())
                            {
                                var label = dayLayout.Children.OfType<Label>().FirstOrDefault();
                                var check = dayLayout.Children.OfType<CheckBox>().FirstOrDefault();

                                
                                //await DisplayAlert("Save No EvryDay", $"Label {label != null} check {check != null}", "OK");
                                if (label != null && check != null && check.IsChecked)
                                {
                                    // ไม่่ทำงาน
                                    //await DisplayAlert("Save No EvryDay", $" {title}", "OK");
                                    await App.Database.SaveActivityAsync(new ActivityModel
                                    {
                                        UserId = userId,
                                        Title = title,
                                        DayOfWeek = label.Text,
                                        StartTime = startTime,
                                        EndTime = endTime,
                                        CrossesMidnight = TimeSpan.Parse(startTime) > TimeSpan.Parse(endTime),
                                        IsEveryWeek = true
                                    });

                                }
                            }
                        }
                    }
                }
            }
        }

        await DisplayAlert("Success", "Settings saved successfully!", "OK");
        await Navigation.PushAsync(new Views.CalendarPage());
    }

    private async void TimeButton_Clicked(object sender, EventArgs e)
    {
        var result = await DisplayActionSheet("Select Time", "Cancel", null, GenerateHourOptions());
        if (result != null && result != "Cancel")
        {
            Button clickedButton = sender as Button;
            clickedButton.Text = result;
        }
    }

    private string[] GenerateHourOptions()
    {
        List<string> options = new List<string>();
        for (int hour = 0; hour < 24; hour++)
        {
            options.Add($"{hour:D2}:00");
        }
        return options.ToArray();
    }

    private void AddButton_Ckicked(object sender, EventArgs e)
    {
        var border = new Border
        {
            StyleId = "CustomActivity", // ✅ ให้ Save รู้ว่านี่คือกิจกรรมเสริม
            BackgroundColor = Colors.White,
            StrokeShape = new RoundRectangle { CornerRadius = 10 },
            Stroke = Colors.White,
            Margin = new Thickness(0, 20, 0, 0)
        };

        var grid = new Grid
        {
            Padding = new Thickness(20, 10),
            ColumnDefinitions = { new ColumnDefinition(), new ColumnDefinition() },
            RowDefinitions =
        {
            new RowDefinition(), new RowDefinition(), new RowDefinition(),
            new RowDefinition(), new RowDefinition(), new RowDefinition(),
            new RowDefinition(), new RowDefinition(), new RowDefinition()
        }
        };

        // Title
        grid.Add(new Label
        {
            Text = "Title",
            FontAttributes = FontAttributes.Bold,
            VerticalOptions = LayoutOptions.Center,
            Padding = 10
        }, 0, 0);

        var titleEntry = new Entry
        {
            Text = "Break",
            WidthRequest = 80,
            HeightRequest = 40,
            HorizontalOptions = LayoutOptions.End,
            BackgroundColor = Colors.White,
            TextColor = Colors.Black,
            Margin = new Thickness(0, 10)
        };
        grid.Add(titleEntry, 1, 0);

        // BoxView 1
        var box1 = new BoxView { HeightRequest = 2, BackgroundColor = Color.FromArgb("#F2F2F7") };
        grid.Add(box1, 0, 1);
        Grid.SetColumnSpan(box1, 2);

        // Starts
        grid.Add(new Label
        {
            Text = "Starts",
            FontAttributes = FontAttributes.Bold,
            VerticalOptions = LayoutOptions.Center,
            Padding = 10
        }, 0, 2);

        var startBtn = new Button
        {
            Text = "08:00",
            WidthRequest = 80,
            HeightRequest = 40,
            HorizontalOptions = LayoutOptions.End,
            Margin = new Thickness(0, 10)
        };
        startBtn.Clicked += TimeButton_Clicked;
        grid.Add(startBtn, 1, 2); // Row 2 สำคัญสำหรับ save

        // BoxView 2
        var box2 = new BoxView { HeightRequest = 2, BackgroundColor = Color.FromArgb("#F2F2F7") };
        grid.Add(box2, 0, 3);
        Grid.SetColumnSpan(box2, 2);

        // Ends
        grid.Add(new Label
        {
            Text = "Ends",
            FontAttributes = FontAttributes.Bold,
            VerticalOptions = LayoutOptions.Center,
            Padding = 10
        }, 0, 4);

        var endBtn = new Button
        {
            Text = "18:00",
            WidthRequest = 80,
            HeightRequest = 40,
            HorizontalOptions = LayoutOptions.End,
            Margin = new Thickness(0, 10)
        };
        endBtn.Clicked += TimeButton_Clicked;
        grid.Add(endBtn, 1, 4); // Row 4 สำคัญสำหรับ save

        // EveryDay checkbox
        var everyDayCheckBox = new CheckBox { IsChecked = true, StyleId = "EveryDayCheck" };
        var everyDayLabel = new Label
        {
            Text = "Every Day",
            VerticalOptions = LayoutOptions.Center,
            FontAttributes = FontAttributes.Bold,
            Padding = 10
        };

        var everyDayLayout = new StackLayout
        {
            Orientation = StackOrientation.Horizontal,
            Children = { everyDayLabel, everyDayCheckBox },
            Margin = new Thickness(10, 10, 0, 10),
        };

        // วันรายวัน
        var dayStack = new StackLayout { Orientation = StackOrientation.Vertical, Margin = new Thickness(0, 0), IsVisible = false, Padding = 15};
        string[] days = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };

        foreach (var day in days)
        {
            var dayLayout = new StackLayout { Orientation = StackOrientation.Horizontal };
            dayLayout.Children.Add(new Label
            {
                Text = day,
                VerticalOptions = LayoutOptions.Center,
                FontAttributes = FontAttributes.None,
            });
            dayLayout.Children.Add(new CheckBox { HorizontalOptions = LayoutOptions.EndAndExpand });
            dayStack.Children.Add(dayLayout);
        }

        everyDayCheckBox.CheckedChanged += (s, e) =>
        {
            dayStack.IsVisible = !e.Value;
        };

        // ปุ่มลบ
        var deleteButton = new Button
        {
            Text = "Delete",
            TextColor = Colors.White,
            BackgroundColor = Colors.Transparent,
            Background = Colors.Red,
            WidthRequest = 80,
            HeightRequest = 40,
            HorizontalOptions = LayoutOptions.End,
            Margin = new Thickness(0, 0, 20, 20)
        };
        deleteButton.Clicked += (s, e) =>
        {
            settingStackLayout.Children.Remove(border);
        };

        // รวมทั้งหมด
        var wrapperStack = new StackLayout
        {
            Children =
        {
            grid,
            everyDayLayout,
            dayStack,
            deleteButton
        }
        };

        border.Content = wrapperStack;
        settingStackLayout.Children.Add(border);
    }

}