﻿using LifetimeApp.Models;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Layouts;
using System;

namespace LifetimeApp.Views;

public partial class SingleDayPage : ContentPage
{
    // ใน class ของคุณ (เช่น public partial class YourPage : ContentPage)
    private List<string> FriendlyNames { get; set; } = new List<string>();


    public SingleDayPage()
    {
        InitializeComponent();
        string todayText = DateTime.Now.ToString("dd MMM yyyy");
        startDateButton.Text = todayText;
        endDateButton.Text = todayText;

        // เวลาปัจจุบัน
        DateTime now = DateTime.Now;
        DateTime nextFullHour = now.Minute > 0 || now.Second > 0
            ? new DateTime(now.Year, now.Month, now.Day, now.Hour, 0, 0).AddHours(1)
            : now;

        startTimeButton.Text = nextFullHour.ToString("HH:mm");
        endTimeButton.Text = nextFullHour.AddHours(1).ToString("HH:mm");

    }

    private async void OnBackClicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void OnAddClicked(object sender, EventArgs e)
    {
        // ตรวจสอบข้อมูลที่จำเป็น
        if (string.IsNullOrWhiteSpace(activityTitleEntry.Text))
        {
            await DisplayAlert("Error", "Please enter activity title", "OK");
            return;
        }

        // ดึงข้อมูลผู้ใช้
        int userId = Preferences.Get("LoggedInUserId", -1);
        if (userId == -1)
        {
            await DisplayAlert("Error", "User not found", "OK");
            return;
        }

        // ตรวจสอบว่าเป็น All Day หรือไม่
        bool isAllDay = !startTimeButton.IsVisible;

        if (isAllDay)
        {
            // สร้างกิจกรรมทั้งวัน
            await CreateAllDayActivity(userId);
        }
        else
        {
            // ตรวจสอบเวลาทับซ้อนสำหรับแต่ละวันในช่วงวันที่เลือก
            bool hasOverlap = true;
            var startDate = hiddenStartDatePicker.Date;
            var endDate = hiddenEndDatePicker.Date;
            var startTime = TimeSpan.Parse(startTimeButton.Text);
            var endTime = TimeSpan.Parse(endTimeButton.Text);

            // ตรวจสอบแต่ละวันในช่วงที่เลือก
            for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
            {
                    hasOverlap = await HasTimeOverlap(userId, date, startTime, endTime);
                    break;
            }

            if (hasOverlap)
            {
                await DisplayAlert("Warning", "This activity overlaps with existing activities", "OK");
                return;
            }

            // สร้างกิจกรรมปกติ
            await CreateRegularActivity(userId);
        }

        // ปิดหน้าและกลับไปยังปฏิทิน
        await Navigation.PopAsync();
    }

    private async Task CreateAllDayActivity(int userId)
    {
        var startDate = hiddenStartDatePicker.Date;
        var endDate = hiddenEndDatePicker.Date;

        for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
        {
            if (FriendlyNames.Count == 0)
            {
                var activity = new ActivityModel
                {
                    UserId = userId,
                    Title = activityTitleEntry.Text,
                    DayOfWeek = date.DayOfWeek.ToString(),
                    StartTime = "00:00",
                    EndTime = "23:59",
                    IsAllDay = true,
                    Date = date,
                    FriendNames = string.Empty
                };
                await App.Database.SaveActivityAsync(activity);
            }
            else
            {
                foreach (var friend in FriendlyNames)
                {
                    var activity = new ActivityModel
                    {
                        UserId = userId,
                        Title = activityTitleEntry.Text + $" ({friend})", // optional
                        DayOfWeek = date.DayOfWeek.ToString(),
                        StartTime = "00:00",
                        EndTime = "23:59",
                        IsAllDay = true,
                        Date = date,
                        FriendNames = friendGrid.Text
                    };
                    await App.Database.SaveActivityAsync(activity);
                }
            }
        }

        await DisplayAlert("Success", "All-day activity added", "OK");
    }



    private async Task CreateRegularActivity(int userId)
    {
        var startDate = hiddenStartDatePicker.Date;
        var endDate = hiddenEndDatePicker.Date;
        var startTime = startTimeButton.Text;
        var endTime = endTimeButton.Text;

        for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
        {
                var activity = new ActivityModel
                {
                    UserId = userId,
                    Title = activityTitleEntry.Text,
                    DayOfWeek = date.DayOfWeek.ToString(),
                    StartTime = startTime,
                    EndTime = endTime,
                    IsAllDay = false,
                    Date = date,
                    FriendNames = friendGrid.Text
                };
                await App.Database.SaveActivityAsync(activity);

        }

        await DisplayAlert("Success", "Activity added", "OK");
    }


    private void DisplayHourOptions(bool isStartTime)
    {
        timeOptionsLayoutStartScroll.IsVisible = false;
        timeOptionsLayoutEndScroll.IsVisible = false;

        var targetLayout = isStartTime ? timeOptionsLayoutStart : timeOptionsLayoutEnd;
        var scrollContainer = isStartTime ? timeOptionsLayoutStartScroll : timeOptionsLayoutEndScroll;
        var targetButton = isStartTime ? startTimeButton : endTimeButton;

        targetLayout.Children.Clear();

        int hourStart = 0;
        int hourEnd = 23;

        if (hiddenStartDatePicker.Date == DateTime.Today)
            hourStart = DateTime.Now.Hour + 1;

        // ถ้าเลือก EndTime → ต้องเริ่มหลัง StartTime
        if (!isStartTime)
        {
            if (TimeSpan.TryParse(startTimeButton.Text, out var startTime))
            {
                hourStart = startTime.Hours + 1;
            }
        }

        for (int hour = hourStart; hour <= hourEnd; hour++)
        {
            string timeText = $"{hour:00}:00";
            var button = new Button
            {
                Text = timeText,
                Margin = new Thickness(5, 2),
            };

            button.Clicked += (s, e) =>
            {
                if (isStartTime)
                {
                    startTimeButton.Text = timeText;

                    if (TimeSpan.TryParse(timeText, out var selectedStartTime)
                        && TimeSpan.TryParse(endTimeButton.Text, out var currentEndTime))
                    {
                        if (currentEndTime <= selectedStartTime)
                        {
                            // ถ้า EndTime เดิมน้อยกว่าหรือเท่ากับ StartTime ให้ปรับใหม่
                            int newEndHour = selectedStartTime.Hours + 1;
                            if (newEndHour <= 23)
                            {
                                endTimeButton.Text = $"{newEndHour:00}:00";
                            }
                            else
                            {
                                endTimeButton.Text = "23:59";
                            }
                        }
                        // ถ้า EndTime เดิมยังอยู่หลัง StartTime → ไม่ต้องทำอะไร
                    }
                }
                else
                {
                    endTimeButton.Text = timeText;
                }

                scrollContainer.IsVisible = false;
            };


            targetLayout.Children.Add(button);
        }

        scrollContainer.IsVisible = true;
    }

    private void OnStartDateButtonClicked(object sender, EventArgs e)
    {
        hiddenStartDatePicker.Focus();
    }

    private void OnEndDateButtonClicked(object sender, EventArgs e)
    {
        hiddenEndDatePicker.Focus();
    }

    private void OnStartDateSelected(object sender, DateChangedEventArgs e)
    {
        startDateButton.Text = e.NewDate.ToString("dd MMM yyyy");

        if (hiddenEndDatePicker.Date < e.NewDate)
        {
            hiddenEndDatePicker.Date = e.NewDate;
            endDateButton.Text = e.NewDate.ToString("dd MMM yyyy");
        }

        hiddenEndDatePicker.MinimumDate = e.NewDate;
    }

    private void OnEndDateSelected(object sender, DateChangedEventArgs e)
    {
        endDateButton.Text = e.NewDate.ToString("dd MMM yyyy");
    }

    private void OnTapOutside(object sender, EventArgs e)
    {
        timeOptionsLayoutStart.IsVisible = false;
        timeOptionsLayoutEnd.IsVisible = false;
    }

    private void OnScrollChanged(object sender, EventArgs e)
    {
        timeOptionsLayoutStart.IsVisible = false;
        timeOptionsLayoutEnd.IsVisible = false;
    }

    private void AllDayCkeck(object sender, EventArgs e)
    {
        if (startTimeButton.IsVisible == true && endTimeButton.IsVisible == true)
        {
            startTimeButton.IsVisible = false;
            endTimeButton.IsVisible = false;
            startDateButton.SetValue(Grid.ColumnProperty, 2);
            endDateButton.SetValue(Grid.ColumnProperty, 2);
            hiddenStartDatePicker.SetValue(Grid.ColumnProperty, 2);
            hiddenEndDatePicker.SetValue(Grid.ColumnProperty, 2);
        }
        else
        {
            startTimeButton.IsVisible = true;
            endTimeButton.IsVisible = true;
            startDateButton.SetValue(Grid.ColumnProperty, 1);
            endDateButton.SetValue(Grid.ColumnProperty, 1);
            hiddenStartDatePicker.SetValue(Grid.ColumnProperty, 1);
            hiddenEndDatePicker.SetValue(Grid.ColumnProperty, 1);
        }
    }


    private async Task<bool> HasTimeOverlap(int userId, DateTime date, TimeSpan newStart, TimeSpan newEnd)
    {
        // ดึงกิจกรรมที่มีอยู่สำหรับวันนั้น
        var existingActivities = await App.Database.GetActivitiesByDateAsync(userId, date);

        foreach (var activity in existingActivities)
        {
            // ข้ามกิจกรรม All Day
            if (activity.IsAllDay) continue;

            var existingStart = TimeSpan.Parse(activity.StartTime);
            var existingEnd = TimeSpan.Parse(activity.EndTime);

            // ตรวจสอบการทับซ้อน
            if (activity.CrossesMidnight == true)
            {
                if (newStart < existingEnd)
                {
                    return true;
                }
                else if (newStart > existingStart)
                {
                    return true;
                }
                else if (newEnd < existingEnd)
                {
                    return true;
                }
                else if (newEnd > existingStart)
                {
                    return true;
                }

            }
            else if (newStart >= existingStart && newStart < existingEnd)
            {
                return true;
            }
            else if (newEnd > existingStart && newEnd <= existingEnd)
            {
                return true;
            }
            else if (newStart <= existingStart && newEnd >= existingEnd)
            {
                return true;
            }

        }

        return false;
    }

    private void OnStartTimeButtonClicked(object sender, EventArgs e)
    {
        // ตรวจสอบว่ามีเมธอด DisplayHourOptions หรือไม่
        DisplayHourOptions(true);
    }

    private void OnEndTimeButtonClicked(object sender, EventArgs e)
    {
        DisplayHourOptions(false);
    }
}
