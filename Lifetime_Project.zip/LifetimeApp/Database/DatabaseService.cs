﻿using LifetimeApp.Models;
using SQLite;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LifetimeApp.Database
{
    public class DatabaseService
    {
        public UserDatabase UserDb { get; }

        private readonly SQLiteAsyncConnection _database;

        public DatabaseService(string dbPath)
        {
            _database = new SQLiteAsyncConnection(dbPath);
            UserDb = new UserDatabase(dbPath);

            //Activity
            //database = new SQLiteAsyncConnection(dbPath);
            //database.CreateTableAsync<User>().Wait();

            //_database.CreateTableAsync<ActivityModel>().Wait();
        }
        // ---------- Activity ----------
        public Task<int> SaveActivityAsync(ActivityModel activity)
        {
            // *****************************************************
            if (activity.Id != 0)
                return _database.UpdateAsync(activity);
            else
                return _database.InsertAsync(activity);
        }

        public Task<List<ActivityModel>> GetActivitiesByUserIdAsync(int userId)
        {
            return _database.Table<ActivityModel>().Where(a => a.UserId == userId).ToListAsync();
        }

        public Task<ActivityModel> GetActivityByIdAsync(int id)
        {
            return _database.Table<ActivityModel>().FirstOrDefaultAsync(a => a.Id == id);
        }

        public Task<int> DeleteActivityAsync(ActivityModel activity)
        {
            return _database.DeleteAsync(activity);
        }

        public Task<int> DeleteActivitiesByUserIdAsync(int userId)
        {
            return _database.Table<ActivityModel>()
                .Where(a => a.UserId == userId)
                .DeleteAsync();
        }

        public async Task<List<ActivityModel>> GetActivitiesByDateAsync(int userId, DateTime date)
        {
            var dayOfWeek = date.DayOfWeek.ToString();
            return await _database.Table<ActivityModel>()
                .Where(a => a.UserId == userId &&
                            (a.DayOfWeek == "EveryDay" || a.DayOfWeek == dayOfWeek))
                .ToListAsync();
        }

        // ---------- User ----------
        public Task<User> GetUserByIdAsync(int userId)
        {
            return _database.Table<User>().FirstOrDefaultAsync(u => u.Id == userId);
        }

        public Task<User> GetUserByUsernameAsync(string username)
        {
            return _database.Table<User>().FirstOrDefaultAsync(u => u.UserName == username);
        }

        public Task<int> UpdateUserAsync(User user)
        {
            return _database.UpdateAsync(user);
        }

        public Task<int> SaveUserAsync(User user)
        {
            if (user.Id != 0)
                return _database.UpdateAsync(user);
            else
                return _database.InsertAsync(user);
        }

        public Task<int> UpdateActivityAsync(ActivityModel activity)
        {
            return _database.UpdateAsync(activity);
        }

    }
}
