﻿using SQLite;
using System.Threading.Tasks;
using System.Collections.Generic;
using LifetimeApp.Models;

public class UserDatabase
{
    private readonly SQLiteAsyncConnection database;

    public UserDatabase(string dbPath)
    {
        database = new SQLiteAsyncConnection(dbPath);
        database.CreateTableAsync<User>().Wait();
        database.CreateTableAsync<ActivityModel>().Wait();
    }

    public Task<User> GetUserByUsernameAsync(string username)
    {
        return database.Table<User>().Where(u => u.UserName == username).FirstOrDefaultAsync();
    }

    public Task<List<User>> GetUserAllAsync()
    {
        return database.Table<User>().ToListAsync();
    }

    public Task<User> GetUserByIdAsync(int id)
    {
        return database.Table<User>().Where(u => u.Id == id).FirstOrDefaultAsync();
    }

    public Task<int> UpdateUserAsync(User user)
    {
        return database.UpdateAsync(user);
    }

    public Task<int> SaveUserAsync(User user)
    {
        return database.InsertAsync(user);
    }

    public Task<int> SaveOrUpdateUserAsync(User user)
    {
        return database.InsertOrReplaceAsync(user);
    }

    internal async Task SaveActivityAsync(ActivityModel activity)
    {
        throw new NotImplementedException();
    }

    public Task<List<ActivityModel>> GetActivitiesByUserIdAsync(int userId)
    {
        return database.Table<ActivityModel>().Where(a => a.UserId == userId).ToListAsync();
    }

    public Task<List<ActivityModel>> GetActivitiesByDateAsync(int userId, DateTime date)
    {
        var dayOfWeek = date.DayOfWeek.ToString();

        return database.Table<ActivityModel>()
            .Where(a => a.UserId == userId &&
                       (a.DayOfWeek == "EveryDay" || a.DayOfWeek == dayOfWeek))
            .ToListAsync();
    }

    public Task<int> DeleteActivitiesByUserIdAsync(int userId)
    {
        return database.Table<ActivityModel>()
                       .Where(a => a.UserId == userId)
                       .DeleteAsync();
    }
}
